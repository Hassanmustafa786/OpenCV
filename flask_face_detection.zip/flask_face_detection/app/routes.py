# app/routes.py
import os
import cv2
import numpy as np
import base64
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename

bp = Blueprint("app", __name__)
UPLOAD_FOLDER = "app/static/uploads"
TEMP_FOLDER = "app/static/temp"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMP_FOLDER, exist_ok=True)

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

@bp.route("/", methods=["GET", "POST"])
def index():
    detected_faces = None  # Initialize the detected_faces variable
    if request.method == "POST":
        if "file" in request.files:
            # Upload from file
            file = request.files["file"]
            detected_faces = process_image(file)
        elif "capture" in request.form:
            # Capture from camera
            image_data = request.form["imageData"]
            detected_faces = process_camera(image_data)

    return render_template("index.html", detected_faces=detected_faces)

def process_image(file):
    if file.filename == "":
        flash("No selected file")
        return None

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    file.save(filepath)
    # Perform face detection and save bounding box areas in the temp folder
    detected_faces = detect_faces(filepath, filename)
    flash("Face detection completed successfully!")
    return detected_faces

def process_camera(image_data):
    # Convert base64-encoded image data to OpenCV format
    nparr = np.frombuffer(base64.b64decode(image_data.split(',')[1]), np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if frame is not None:
        # Save the captured frame temporarily
        temp_filepath = os.path.join(TEMP_FOLDER, "captured_frame.jpg")
        cv2.imwrite(temp_filepath, frame)

        # Perform face detection on the captured frame
        detected_faces = detect_faces(temp_filepath, "captured_frame.jpg")

        flash("Face detection completed successfully!")
        return detected_faces
    else:
        flash("Unable to process camera image")
        return None

def detect_faces(filepath, filename):
    img = cv2.imread(filepath)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5, minSize=(30, 30))

    detected_faces = []  # Initialize the list to store detected faces

    for i, (x, y, w, h) in enumerate(faces):
        face_img = img[y:y + h, x:x + w]
        temp_filepath = os.path.join(TEMP_FOLDER, f"{filename}face{i}.jpg")
        cv2.imwrite(temp_filepath, face_img)
        detected_faces.append(f"{filename}face{i}.jpg")  # Add the detected face to the list

    return detected_faces